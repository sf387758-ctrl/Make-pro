#include "PluginProcessor.h"
#include "PluginEditor.h"

BM800ToProAudioProcessorEditor::BM800ToProAudioProcessorEditor(BM800ToProAudioProcessor& p)
    : AudioProcessorEditor(&p), audioProcessor(p)
{
    setLookAndFeel(&customLookAndFeel);

    auto setupKnob = [this](juce::Slider& slider, const juce::String& name, const juce::String& paramId,
                            std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment>& attachment)
    {
        slider.setName(name);
        slider.setSliderStyle(juce::Slider::RotaryVerticalDrag);
        slider.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 65, 20);
        slider.setColour(juce::Slider::textBoxTextColourId, juce::Colour(0xffe2e8f0));
        slider.setColour(juce::Slider::textBoxOutlineColourId, juce::Colours::transparentBlack);
        addAndMakeVisible(slider);
        attachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(
            audioProcessor.getAPVTS(), paramId, slider);
    };

    setupKnob(cleanSlider, "clean", "clean", cleanAttachment);
    setupKnob(bodySlider, "body", "body", bodyAttachment);
    setupKnob(proAirSlider, "pro_air", "pro_air", proAirAttachment);
    setupKnob(smoothSlider, "smooth", "smooth", smoothAttachment);
    setupKnob(loudSlider, "loud", "loud", loudAttachment);

    // Top Bar A/B Bypass Button
    bypassButton.setColour(juce::ToggleButton::textColourId, juce::Colour(0xff94a3b8));
    bypassButton.setColour(juce::ToggleButton::tickColourId, juce::Colour(0xfff43f5e));
    addAndMakeVisible(bypassButton);
    bypassAttachment = std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment>(
        audioProcessor.getAPVTS(), "bypass", bypassButton);

    // Bottom Bar Presets
    auto setupPresetBtn = [this](juce::TextButton& btn, int index)
    {
        btn.setColour(juce::TextButton::buttonColourId, juce::Colour(0xff1e293b));
        btn.setColour(juce::TextButton::textColourOffId, juce::Colour(0xffcbd5e1));
        btn.onClick = [this, index]() { audioProcessor.applyPreset(index); };
        addAndMakeVisible(btn);
    };

    setupPresetBtn(bm800WarmBtn, 0);
    setupPresetBtn(boyaClearBtn, 1);
    setupPresetBtn(podcastProBtn, 2);

    setSize(880, 520);
    startTimerHz(30); // 30 FPS meter update
}

BM800ToProAudioProcessorEditor::~BM800ToProAudioProcessorEditor()
{
    stopTimer();
    setLookAndFeel(nullptr);
}

void BM800ToProAudioProcessorEditor::timerCallback()
{
    float rawIn = audioProcessor.getInputMeterLevel();
    float rawOut = audioProcessor.getOutputMeterLevel();

    smoothedInLevel = smoothedInLevel * 0.7f + rawIn * 0.3f;
    smoothedOutLevel = smoothedOutLevel * 0.7f + rawOut * 0.3f;

    repaint();
}

void BM800ToProAudioProcessorEditor::paint(juce::Graphics& g)
{
    // 1. Brushed Metal Dark Chassis Background
    g.fillAll(juce::Colour(0xff0b0e14));

    // Vintage Rack Screws (4 corners)
    g.setColour(juce::Colour(0xff334155));
    g.fillEllipse(12, 12, 10, 10);
    g.fillEllipse(getWidth() - 22, 12, 10, 10);
    g.fillEllipse(12, getHeight() - 22, 10, 10);
    g.fillEllipse(getWidth() - 22, getHeight() - 22, 10, 10);

    // Rack Bezel Hairline
    g.setColour(juce::Colour(0xff1e293b));
    g.drawRect(getLocalBounds().toFloat(), 1.0f);

    // 2. TOP BAR (Height: 70px)
    g.setColour(juce::Colour(0xff0f172a));
    g.fillRect(0, 0, getWidth(), 70);
    g.setColour(juce::Colour(0xff1e293b));
    g.drawHorizontalLine(70, 0.0f, (float)getWidth());

    // Plugin Title Wordmark
    g.setFont(juce::Font(juce::Font::getDefaultSansSerifName(), 20.0f, juce::Font::bold));
    g.setColour(juce::Colour(0xfff8fafc));
    g.drawText("BM800 TO PRO", 36, 16, 220, 24, juce::Justification::left);

    g.setFont(juce::Font(juce::Font::getDefaultMonospacedFontName(), 11.0f, juce::Font::plain));
    g.setColour(juce::Colour(0xff06b6d4));
    g.drawText("VOCAL ENHANCER  |  NEUMANN & SM7B DSP MODEL", 36, 38, 320, 16, juce::Justification::left);

    // Stereo Input Meter
    const int meterWidth = 90;
    const int meterHeight = 12;
    int inX = getWidth() - 320;
    int outX = getWidth() - 150;

    auto drawMeter = [&](int x, int y, const juce::String& label, float level)
    {
        g.setFont(juce::Font(juce::Font::getDefaultMonospacedFontName(), 10.0f, juce::Font::bold));
        g.setColour(juce::Colour(0xff94a3b8));
        g.drawText(label, x - 32, y - 1, 28, 14, juce::Justification::right);

        // Meter background
        g.setColour(juce::Colour(0xff020617));
        g.fillRoundedRectangle(x, y, meterWidth, meterHeight, 2.0f);

        // Active LED bar
        float normLevel = juce::jlimit(0.0f, 1.0f, level * 2.5f);
        if (normLevel > 0.01f)
        {
            juce::Colour meterCol = normLevel > 0.85f ? juce::Colour(0xfff43f5e) :
                                    (normLevel > 0.65f ? juce::Colour(0xfff59e0b) : juce::Colour(0xff10b981));
            g.setColour(meterCol);
            g.fillRoundedRectangle(x + 1, y + 1, (meterWidth - 2) * normLevel, meterHeight - 2, 1.5f);
        }
        g.setColour(juce::Colour(0xff334155));
        g.drawRoundedRectangle(x, y, meterWidth, meterHeight, 2.0f, 1.0f);
    };

    drawMeter(inX, 29, "IN", smoothedInLevel);
    drawMeter(outX, 29, "OUT", smoothedOutLevel);

    // 3. MAIN CHANNEL STRIP - 5 KNOBS LABELS
    const int startX = 40;
    const int knobSpacing = 160;
    const int labelY = 100;

    struct KnobMeta {
        juce::String title;
        juce::String subtitle;
        juce::Colour color;
    };

    std::vector<KnobMeta> metas = {
        { "1. CLEAN", "NOISE KILLER / 80Hz", juce::Colour(0xff06b6d4) },
        { "2. BODY", "150Hz BASS & TUBE", juce::Colour(0xfff59e0b) },
        { "3. PRO AIR", "10kHz PRESENCE", juce::Colour(0xff38bdf8) },
        { "4. SMOOTH", "DE-ESS / HARSH FIX", juce::Colour(0xff10b981) },
        { "5. LOUD", "PRO VOLUME & LIMIT", juce::Colour(0xfff43f5e) }
    };

    for (size_t i = 0; i < metas.size(); ++i)
    {
        int x = startX + i * knobSpacing;
        g.setFont(juce::Font(juce::Font::getDefaultSansSerifName(), 14.0f, juce::Font::bold));
        g.setColour(metas[i].color);
        g.drawText(metas[i].title, x, labelY, 140, 20, juce::Justification::centred);

        g.setFont(juce::Font(juce::Font::getDefaultMonospacedFontName(), 9.0f, juce::Font::plain));
        g.setColour(juce::Colour(0xff64748b));
        g.drawText(metas[i].subtitle, x, labelY + 18, 140, 16, juce::Justification::centred);
    }

    // 4. BOTTOM BAR
    g.setColour(juce::Colour(0xff0a0f1d));
    g.fillRect(0, getHeight() - 65, getWidth(), 65);
    g.setColour(juce::Colour(0xff1e293b));
    g.drawHorizontalLine(getHeight() - 65, 0.0f, (float)getWidth());

    g.setFont(juce::Font(juce::Font::getDefaultSansSerifName(), 12.0f, juce::Font::bold));
    g.setColour(juce::Colour(0xff94a3b8));
    g.drawText("QUICK PRESETS:", 40, getHeight() - 44, 110, 24, juce::Justification::left);
}

void BM800ToProAudioProcessorEditor::resized()
{
    bypassButton.setBounds(getWidth() - 460, 24, 120, 24);

    const int startX = 40;
    const int knobSpacing = 160;
    const int knobY = 150;
    const int knobSize = 140;

    cleanSlider.setBounds(startX + 0 * knobSpacing, knobY, knobSize, knobSize);
    bodySlider.setBounds(startX + 1 * knobSpacing, knobY, knobSize, knobSize);
    proAirSlider.setBounds(startX + 2 * knobSpacing, knobY, knobSize, knobSize);
    smoothSlider.setBounds(startX + 3 * knobSpacing, knobY, knobSize, knobSize);
    loudSlider.setBounds(startX + 4 * knobSpacing, knobY, knobSize, knobSize);

    // Bottom Presets
    bm800WarmBtn.setBounds(160, getHeight() - 46, 130, 28);
    boyaClearBtn.setBounds(305, getHeight() - 46, 130, 28);
    podcastProBtn.setBounds(450, getHeight() - 46, 130, 28);
}
