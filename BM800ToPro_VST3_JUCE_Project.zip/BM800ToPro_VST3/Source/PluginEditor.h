#pragma once

#include <juce_gui_extra/juce_gui_extra.h>
#include "PluginProcessor.h"
#include "CustomLookAndFeel.h"

class BM800ToProAudioProcessorEditor : public juce::AudioProcessorEditor,
                                       public juce::Timer
{
public:
    BM800ToProAudioProcessorEditor(BM800ToProAudioProcessor&);
    ~BM800ToProAudioProcessorEditor() override;

    void paint(juce::Graphics&) override;
    void resized() override;
    void timerCallback() override;

private:
    BM800ToProAudioProcessor& audioProcessor;
    ProHardwareLookAndFeel customLookAndFeel;

    // 5 Glowing Channel Strip Knobs
    juce::Slider cleanSlider;
    juce::Slider bodySlider;
    juce::Slider proAirSlider;
    juce::Slider smoothSlider;
    juce::Slider loudSlider;

    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> cleanAttachment;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> bodyAttachment;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> proAirAttachment;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> smoothAttachment;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> loudAttachment;

    // Top Bar Controls
    juce::ToggleButton bypassButton { "A/B (BYPASS)" };
    std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment> bypassAttachment;

    // Bottom Bar Presets
    juce::TextButton bm800WarmBtn { "BM800 Warm" };
    juce::TextButton boyaClearBtn { "Boya Clear" };
    juce::TextButton podcastProBtn { "Podcast Pro" };

    // Real-time smoothed meters
    float smoothedInLevel = 0.0f;
    float smoothedOutLevel = 0.0f;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(BM800ToProAudioProcessorEditor)
};
