#pragma once

#include <juce_gui_extra/juce_gui_extra.h>

/**
 * Custom Dark Pro Hardware LookAndFeel.
 * Heavy brushed aluminum knobs, glowing radial status rings,
 * phosphor LED indicators and tactile analog studio switches.
 */
class ProHardwareLookAndFeel : public juce::LookAndFeel_V4
{
public:
    ProHardwareLookAndFeel()
    {
        setColour(juce::Slider::thumbColourId, juce::Colour(0xff22d3ee));
        setColour(juce::Slider::rotarySliderFillColourId, juce::Colour(0xff06b6d4));
        setColour(juce::Slider::rotarySliderOutlineColourId, juce::Colour(0xff1e293b));
    }

    void drawRotarySlider(juce::Graphics& g, int x, int y, int width, int height,
                          float sliderPosProportional, float rotaryStartAngle,
                          float rotaryEndAngle, juce::Slider& slider) override
    {
        const float radius = juce::jmin(width / 2.0f, height / 2.0f) - 6.0f;
        const float centreX = x + width * 0.5f;
        const float centreY = y + height * 0.5f;
        const float rx = centreX - radius;
        const float ry = centreY - radius;
        const float rw = radius * 2.0f;
        const float angle = rotaryStartAngle + sliderPosProportional * (rotaryEndAngle - rotaryStartAngle);

        // Knob Glow Color based on slider name/style
        juce::Colour glowColour = juce::Colour(0xff06b6d4); // Default Cyan
        if (slider.getName() == "body")
            glowColour = juce::Colour(0xfff59e0b); // Amber for warmth
        else if (slider.getName() == "pro_air")
            glowColour = juce::Colour(0xff38bdf8); // Sky Blue for air
        else if (slider.getName() == "smooth")
            glowColour = juce::Colour(0xff10b981); // Emerald for smooth
        else if (slider.getName() == "loud")
            glowColour = juce::Colour(0xfff43f5e); // Rose for loud

        // 1. Outer Dark Bezel / Shadow
        g.setColour(juce::Colour(0xff05070a));
        g.fillEllipse(rx - 3.0f, ry - 3.0f, rw + 6.0f, rw + 6.0f);

        // 2. Track Background Arc (Dark Slate)
        juce::Path trackPath;
        trackPath.addCentredArc(centreX, centreY, radius - 2.0f, radius - 2.0f, 0.0f, rotaryStartAngle, rotaryEndAngle, true);
        g.setColour(juce::Colour(0xff1e293b));
        g.strokePath(trackPath, juce::PathStrokeType(4.5f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

        // 3. Glowing Active Arc
        if (sliderPosProportional > 0.001f)
        {
            juce::Path activePath;
            activePath.addCentredArc(centreX, centreY, radius - 2.0f, radius - 2.0f, 0.0f, rotaryStartAngle, angle, true);
            
            // Soft neon halo
            g.setColour(glowColour.withAlpha(0.35f));
            g.strokePath(activePath, juce::PathStrokeType(8.0f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

            // Sharp active core
            g.setColour(glowColour);
            g.strokePath(activePath, juce::PathStrokeType(4.5f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
        }

        // 4. Brushed Metal Dial Face
        const float dialRadius = radius - 8.0f;
        juce::ColourGradient dialGradient(juce::Colour(0xff2a3447), centreX - dialRadius, centreY - dialRadius,
                                          juce::Colour(0xff0d131f), centreX + dialRadius, centreY + dialRadius, false);
        g.setGradientFill(dialGradient);
        g.fillEllipse(centreX - dialRadius, centreY - dialRadius, dialRadius * 2.0f, dialRadius * 2.0f);

        // Knurled edge outline
        g.setColour(juce::Colour(0xff334155));
        g.drawEllipse(centreX - dialRadius, centreY - dialRadius, dialRadius * 2.0f, dialRadius * 2.0f, 1.5f);

        // Inner recessed dish
        const float dishRadius = dialRadius * 0.72f;
        g.setColour(juce::Colour(0xff090d16));
        g.fillEllipse(centreX - dishRadius, centreY - dishRadius, dishRadius * 2.0f, dishRadius * 2.0f);

        // 5. Dial Indicator Notch / Phosphor Needle
        juce::Path p;
        const float needleLength = dialRadius * 0.75f;
        p.startNewSubPath(centreX, centreY);
        p.lineTo(centreX + std::sin(angle) * needleLength, centreY - std::cos(angle) * needleLength);

        // Needle Glow
        g.setColour(glowColour.withAlpha(0.5f));
        g.strokePath(p, juce::PathStrokeType(5.0f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

        g.setColour(juce::Colours::white);
        g.strokePath(p, juce::PathStrokeType(2.5f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
    }
};
