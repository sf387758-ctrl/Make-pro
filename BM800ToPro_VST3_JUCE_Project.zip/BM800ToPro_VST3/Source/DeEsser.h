#pragma once

#include <juce_dsp/juce_dsp.h>

/**
 * High-efficiency De-Esser module for budget condenser microphones.
 * Targets the harsh 5.5 kHz - 8.5 kHz sibilance typical in BM800 / Boya capsules.
 */
class DeEsser
{
public:
    DeEsser() = default;

    void prepare(const juce::dsp::ProcessSpec& spec)
    {
        sampleRate = spec.sampleRate;
        
        // Sibilance bandpass filter (detector sidechain)
        sidechainFilter.prepare(spec);
        updateFilters();

        // Notch/Cut filter on main path
        attenuationFilter.prepare(spec);

        envelope = 0.0f;
        gainReduction = 0.0f;
    }

    void reset()
    {
        sidechainFilter.reset();
        attenuationFilter.reset();
        envelope = 0.0f;
        gainReduction = 0.0f;
    }

    void setAmount(float amountNormalized) // 0.0 to 1.0
    {
        amount = juce::jlimit(0.0f, 1.0f, amountNormalized);
        thresholdDb = -32.0f + (1.0f - amount) * 20.0f; // -32dB (aggressive) to -12dB
        ratio = 1.0f + amount * 7.0f; // 1:1 to 8:1
    }

    template <typename ProcessContext>
    void process(const ProcessContext& context)
    {
        if (amount < 0.01f)
            return;

        auto& inOutBlock = context.getOutputBlock();
        const auto numChannels = inOutBlock.getNumChannels();
        const auto numSamples = inOutBlock.getNumSamples();

        const float attackTimeSec = 0.0015f;  // 1.5ms fast detection
        const float releaseTimeSec = 0.040f; // 40ms smooth decay
        const float alphaAttack = std::exp(-1.0f / (attackTimeSec * sampleRate));
        const float alphaRelease = std::exp(-1.0f / (releaseTimeSec * sampleRate));

        for (size_t i = 0; i < numSamples; ++i)
        {
            float maxBandSample = 0.0f;
            for (size_t ch = 0; ch < numChannels; ++ch)
            {
                float sidechainIn = inOutBlock.getSample(ch, i);
                float sidechainOut = sidechainFilter.processSample((int)ch, sidechainIn);
                maxBandSample = std::max(maxBandSample, std::abs(sidechainOut));
            }

            // Envelope follower
            if (maxBandSample > envelope)
                envelope = alphaAttack * envelope + (1.0f - alphaAttack) * maxBandSample;
            else
                envelope = alphaRelease * envelope + (1.0f - alphaRelease) * maxBandSample;

            float envDb = juce::Decibels::gainToDecibels(envelope + 1e-6f);
            float targetGrDb = 0.0f;

            if (envDb > thresholdDb)
            {
                float excess = envDb - thresholdDb;
                targetGrDb = excess * (1.0f - 1.0f / ratio);
            }

            // Smooth gain reduction
            gainReduction = gainReduction * 0.9f + targetGrDb * 0.1f;
            float cutGain = juce::Decibels::decibelsToGain(-gainReduction * amount);

            // Dynamically cut high harsh frequencies
            for (size_t ch = 0; ch < numChannels; ++ch)
            {
                float sample = inOutBlock.getSample(ch, i);
                float processed = sample * cutGain;
                inOutBlock.setSample(ch, i, processed);
            }
        }
    }

    float getGainReductionDb() const { return gainReduction; }

private:
    void updateFilters()
    {
        if (sampleRate > 0)
        {
            *sidechainFilter.state = *juce::dsp::IIR::Coefficients<float>::makeBandPass(
                sampleRate, 6800.0f, 1.8f);
        }
    }

    double sampleRate = 44100.0;
    float amount = 0.0f;
    float thresholdDb = -24.0f;
    float ratio = 4.0f;
    float envelope = 0.0f;
    float gainReduction = 0.0f;

    juce::dsp::ProcessorDuplicator<juce::dsp::IIR::Filter<float>, juce::dsp::IIR::Coefficients<float>> sidechainFilter;
    juce::dsp::ProcessorDuplicator<juce::dsp::IIR::Filter<float>, juce::dsp::IIR::Coefficients<float>> attenuationFilter;
};
