#pragma once

#include <juce_dsp/juce_dsp.h>

/**
 * Pro Air Harmonic Exciter.
 * Generates sparkling odd and even musical harmonics above 8 kHz,
 * giving cheap capsules the shimmering sheen of high-end German tube microphones.
 */
class Exciter
{
public:
    Exciter() = default;

    void prepare(const juce::dsp::ProcessSpec& spec)
    {
        sampleRate = spec.sampleRate;
        highPassFilter.prepare(spec);
        updateCoefficients();
    }

    void reset()
    {
        highPassFilter.reset();
    }

    void setAmount(float amountNormalized) // 0.0 to 1.0
    {
        amount = juce::jlimit(0.0f, 1.0f, amountNormalized);
    }

    template <typename ProcessContext>
    void process(const ProcessContext& context)
    {
        if (amount < 0.01f)
            return;

        auto& inOutBlock = context.getOutputBlock();
        const auto numChannels = inOutBlock.getNumChannels();
        const auto numSamples = inOutBlock.getNumSamples();

        for (size_t ch = 0; ch < numChannels; ++ch)
        {
            auto* channelData = inOutBlock.getChannelPointer(ch);

            for (size_t i = 0; i < numSamples; ++i)
            {
                float dry = channelData[i];
                
                // Extract 8kHz+ air band
                float airBand = highPassFilter.processSample((int)ch, dry);

                // Asymmetric soft-curve distortion generates lush 2nd & 3rd harmonics
                float driven = airBand * (1.0f + amount * 3.5f);
                float harmonics = std::tanh(driven) - 0.25f * (driven * driven * driven / 6.0f);

                // Blend sparkling exciter into output
                channelData[i] = dry + harmonics * (amount * 0.35f);
            }
        }
    }

private:
    void updateCoefficients()
    {
        if (sampleRate > 0)
        {
            *highPassFilter.state = *juce::dsp::IIR::Coefficients<float>::makeHighPass(
                sampleRate, 8500.0f, 0.707f);
        }
    }

    double sampleRate = 44100.0;
    float amount = 0.0f;
    juce::dsp::ProcessorDuplicator<juce::dsp::IIR::Filter<float>, juce::dsp::IIR::Coefficients<float>> highPassFilter;
};
