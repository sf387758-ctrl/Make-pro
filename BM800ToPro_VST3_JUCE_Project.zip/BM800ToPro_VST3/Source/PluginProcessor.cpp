#include "PluginProcessor.h"
#include "PluginEditor.h"

BM800ToProAudioProcessor::BM800ToProAudioProcessor()
    : AudioProcessor(BusesProperties().withInput("Input", juce::AudioChannelSet::stereo(), true)
                                      .withOutput("Output", juce::AudioChannelSet::stereo(), true)),
      apvts(*this, nullptr, "Parameters", createParameterLayout())
{
    apvts.addParameterListener("clean", this);
    apvts.addParameterListener("body", this);
    apvts.addParameterListener("pro_air", this);
    apvts.addParameterListener("smooth", this);
    apvts.addParameterListener("loud", this);

    // Warm soft-clipping saturation function
    warmSaturator.functionToUse = [](float x)
    {
        // Smooth analog tape/tube transfer curve
        return std::tanh(1.2f * x);
    };
}

BM800ToProAudioProcessor::~BM800ToProAudioProcessor()
{
    apvts.removeParameterListener("clean", this);
    apvts.removeParameterListener("body", this);
    apvts.removeParameterListener("pro_air", this);
    apvts.removeParameterListener("smooth", this);
    apvts.removeParameterListener("loud", this);
}

juce::AudioProcessorValueTreeState::ParameterLayout BM800ToProAudioProcessor::createParameterLayout()
{
    std::vector<std::unique_ptr<juce::RangedAudioParameter>> params;

    // 5 Core Knobs (0% to 100%)
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID { "clean", 1 }, "Clean (Noise Killer)",
        juce::NormalisableRange<float>(0.0f, 100.0f, 0.1f), 30.0f));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID { "body", 1 }, "Body (Bass Add)",
        juce::NormalisableRange<float>(0.0f, 100.0f, 0.1f), 55.0f));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID { "pro_air", 1 }, "Pro Air (Presence)",
        juce::NormalisableRange<float>(0.0f, 100.0f, 0.1f), 60.0f));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID { "smooth", 1 }, "Smooth (De-Ess & Harsh Fix)",
        juce::NormalisableRange<float>(0.0f, 100.0f, 0.1f), 45.0f));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID { "loud", 1 }, "Loud (Pro Volume)",
        juce::NormalisableRange<float>(0.0f, 100.0f, 0.1f), 50.0f));

    // Top Bar A/B Bypass & Gain Trim
    params.push_back(std::make_unique<juce::AudioParameterBool>(
        juce::ParameterID { "bypass", 1 }, "Bypass", false));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID { "input_trim", 1 }, "Input Trim",
        juce::NormalisableRange<float>(-18.0f, 18.0f, 0.1f), 0.0f));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID { "output_trim", 1 }, "Output Trim",
        juce::NormalisableRange<float>(-18.0f, 18.0f, 0.1f), 0.0f));

    return { params.begin(), params.end() };
}

void BM800ToProAudioProcessor::prepareToPlay(double sampleRate, int samplesPerBlock)
{
    currentSampleRate = sampleRate;

    juce::dsp::ProcessSpec spec;
    spec.sampleRate = sampleRate;
    spec.maximumBlockSize = samplesPerBlock;
    spec.numChannels = getTotalNumOutputChannels();

    highPassFilter.prepare(spec);
    noiseGate.prepare(spec);

    lowShelfFilter.prepare(spec);
    warmSaturator.prepare(spec);
    dcBlocker.prepare(spec);

    highShelfFilter.prepare(spec);
    exciter.prepare(spec);

    deEsser.prepare(spec);
    optoCompressor.prepare(spec);

    fastCompressor.prepare(spec);
    brickwallLimiter.prepare(spec);

    // DC Blocker filter (10Hz High Pass)
    *dcBlocker.state = *juce::dsp::IIR::Coefficients<float>::makeHighPass(sampleRate, 15.0f);

    updateFilters();
}

void BM800ToProAudioProcessor::releaseResources()
{
    highPassFilter.reset();
    noiseGate.reset();
    lowShelfFilter.reset();
    warmSaturator.reset();
    dcBlocker.reset();
    highShelfFilter.reset();
    exciter.reset();
    deEsser.reset();
    optoCompressor.reset();
    fastCompressor.reset();
    brickwallLimiter.reset();
}

bool BM800ToProAudioProcessor::isBusesLayoutSupported(const BusesLayout& layouts) const
{
    if (layouts.getMainOutputChannelSet() != juce::AudioChannelSet::mono()
     && layouts.getMainOutputChannelSet() != juce::AudioChannelSet::stereo())
        return false;

    if (layouts.getMainOutputChannelSet() != layouts.getMainInputChannelSet())
        return false;

    return true;
}

void BM800ToProAudioProcessor::updateFilters()
{
    if (currentSampleRate <= 0.0)
        return;

    const float cleanVal = *apvts.getRawParameterValue("clean");
    const float bodyVal = *apvts.getRawParameterValue("body");
    const float proAirVal = *apvts.getRawParameterValue("pro_air");
    const float smoothVal = *apvts.getRawParameterValue("smooth");
    const float loudVal = *apvts.getRawParameterValue("loud");

    // 1. CLEAN: HPF (80Hz to 120Hz based on clean intensity) + Noise Gate
    float hpfFreq = 75.0f + (cleanVal / 100.0f) * 45.0f;
    *highPassFilter.state = *juce::dsp::IIR::Coefficients<float>::makeHighPass(currentSampleRate, hpfFreq, 0.707f);

    float gateThresholdDb = -65.0f + (cleanVal / 100.0f) * 35.0f; // -65dB (soft) to -30dB (heavy gate)
    noiseGate.setThreshold(gateThresholdDb);
    noiseGate.setRatio(1.0f + (cleanVal / 100.0f) * 10.0f);
    noiseGate.setAttackTime(2.0f);
    noiseGate.setReleaseTime(60.0f);

    // 2. BODY: Low Shelf boost at 150Hz (+0dB to +8.5dB)
    float bodyGainDb = (bodyVal / 100.0f) * 8.5f;
    *lowShelfFilter.state = *juce::dsp::IIR::Coefficients<float>::makeLowShelf(
        currentSampleRate, 150.0f, 0.65f, juce::Decibels::decibelsToGain(bodyGainDb));

    // 3. PRO AIR: High Shelf boost at 10kHz (+0dB to +9.0dB) + Exciter
    float airGainDb = (proAirVal / 100.0f) * 9.0f;
    *highShelfFilter.state = *juce::dsp::IIR::Coefficients<float>::makeHighShelf(
        currentSampleRate, 10000.0f, 0.707f, juce::Decibels::decibelsToGain(airGainDb));
    exciter.setAmount(proAirVal / 100.0f);

    // 4. SMOOTH: De-Esser + Optical Compressor
    deEsser.setAmount(smoothVal / 100.0f);
    float optoThresholdDb = -18.0f - (smoothVal / 100.0f) * 14.0f;
    optoCompressor.setThreshold(optoThresholdDb);
    optoCompressor.setRatio(2.5f + (smoothVal / 100.0f) * 2.0f);
    optoCompressor.setAttackTime(20.0f);
    optoCompressor.setReleaseTime(150.0f);

    // 5. LOUD: Fast FET Compressor + Brickwall Limiter
    float loudThresholdDb = -12.0f - (loudVal / 100.0f) * 16.0f;
    fastCompressor.setThreshold(loudThresholdDb);
    fastCompressor.setRatio(4.0f + (loudVal / 100.0f) * 4.0f);
    fastCompressor.setAttackTime(1.5f);
    fastCompressor.setReleaseTime(45.0f);

    brickwallLimiter.setThreshold(-0.5f); // Safe digital ceiling
    brickwallLimiter.setRelease(50.0f);
}

void BM800ToProAudioProcessor::parameterChanged(const juce::String&, float)
{
    updateFilters();
}

void BM800ToProAudioProcessor::processBlock(juce::AudioBuffer<float>& buffer, juce::MidiBuffer&)
{
    juce::ScopedNoDenormals noDenormals;
    const auto totalNumInputChannels = getTotalNumInputChannels();
    const auto totalNumOutputChannels = getTotalNumOutputChannels();

    for (auto i = totalNumInputChannels; i < totalNumOutputChannels; ++i)
        buffer.clear(i, 0, buffer.getNumSamples());

    // Calculate Input Meter Level
    float inRms = buffer.getRMSLevel(0, 0, buffer.getNumSamples());
    if (totalNumInputChannels > 1)
        inRms = std::max(inRms, buffer.getRMSLevel(1, 0, buffer.getNumSamples()));
    inputMeter.store(inRms);

    // Check A/B Bypass toggle
    bool isBypassed = *apvts.getRawParameterValue("bypass") > 0.5f;
    if (isBypassed)
    {
        outputMeter.store(inRms);
        gainReductionMeter.store(0.0f);
        return;
    }

    // Input Trim
    float inTrimDb = *apvts.getRawParameterValue("input_trim");
    buffer.applyGain(juce::Decibels::decibelsToGain(inTrimDb));

    juce::dsp::AudioBlock<float> block(buffer);
    juce::dsp::ProcessContextReplacing<float> context(block);

    // 1. CLEAN: Noise Gate + High-Pass Filter (80Hz)
    noiseGate.process(context);
    highPassFilter.process(context);

    // 2. BODY: Low Shelf 150Hz + Warm Saturation
    lowShelfFilter.process(context);
    float bodyVal = *apvts.getRawParameterValue("body");
    if (bodyVal > 5.0f)
    {
        warmSaturator.process(context);
        dcBlocker.process(context);
    }

    // 3. PRO AIR: High Shelf 10kHz + Exciter
    highShelfFilter.process(context);
    exciter.process(context);

    // 4. SMOOTH: De-Esser + Opto Compressor
    deEsser.process(context);
    optoCompressor.process(context);

    // 5. LOUD: Fast FET Compressor + Brickwall Limiter
    fastCompressor.process(context);
    brickwallLimiter.process(context);

    // Output Trim
    float outTrimDb = *apvts.getRawParameterValue("output_trim");
    buffer.applyGain(juce::Decibels::decibelsToGain(outTrimDb));

    // Calculate Output Meter Level
    float outRms = buffer.getRMSLevel(0, 0, buffer.getNumSamples());
    if (totalNumOutputChannels > 1)
        outRms = std::max(outRms, buffer.getRMSLevel(1, 0, buffer.getNumSamples()));
    outputMeter.store(outRms);

    // Gain reduction telemetry
    gainReductionMeter.store(deEsser.getGainReductionDb());
}

void BM800ToProAudioProcessor::applyPreset(int presetIndex)
{
    // Preset 0: BM800 Warm (Transforms thin, metallic BM800 into thick, warm studio vocal)
    if (presetIndex == 0)
    {
        apvts.getParameter("clean")->setValueNotifyingHost(0.35f);
        apvts.getParameter("body")->setValueNotifyingHost(0.75f);
        apvts.getParameter("pro_air")->setValueNotifyingHost(0.45f);
        apvts.getParameter("smooth")->setValueNotifyingHost(0.60f);
        apvts.getParameter("loud")->setValueNotifyingHost(0.50f);
    }
    // Preset 1: Boya Clear (Cleans lavalier/lapel boxiness, adds crisp broadcast articulation)
    else if (presetIndex == 1)
    {
        apvts.getParameter("clean")->setValueNotifyingHost(0.70f);
        apvts.getParameter("body")->setValueNotifyingHost(0.40f);
        apvts.getParameter("pro_air")->setValueNotifyingHost(0.65f);
        apvts.getParameter("smooth")->setValueNotifyingHost(0.55f);
        apvts.getParameter("loud")->setValueNotifyingHost(0.45f);
    }
    // Preset 2: Podcast Pro (Upfront, radio-ready SM7B / Joe Rogan broadcast punch)
    else if (presetIndex == 2)
    {
        apvts.getParameter("clean")->setValueNotifyingHost(0.50f);
        apvts.getParameter("body")->setValueNotifyingHost(0.65f);
        apvts.getParameter("pro_air")->setValueNotifyingHost(0.50f);
        apvts.getParameter("smooth")->setValueNotifyingHost(0.45f);
        apvts.getParameter("loud")->setValueNotifyingHost(0.80f);
    }
}

juce::AudioProcessorEditor* BM800ToProAudioProcessor::createEditor()
{
    return new BM800ToProAudioProcessorEditor(*this);
}

void BM800ToProAudioProcessor::getStateInformation(juce::MemoryBlock& destData)
{
    auto state = apvts.copyState();
    std::unique_ptr<juce::XmlElement> xml(state.createXml());
    copyXmlToBinary(*xml, destData);
}

void BM800ToProAudioProcessor::setStateInformation(const void* data, int sizeInBytes)
{
    std::unique_ptr<juce::XmlElement> xmlState(getXmlFromBinary(data, sizeInBytes));
    if (xmlState != nullptr && xmlState->hasTagName(apvts.state.getType()))
        apvts.replaceState(juce::ValueTree::fromXml(*xmlState));
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new BM800ToProAudioProcessor();
}
