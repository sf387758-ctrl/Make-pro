#pragma once

#include <juce_audio_processors/juce_audio_processors.h>
#include <juce_dsp/juce_dsp.h>
#include "DeEsser.h"
#include "Exciter.h"

class BM800ToProAudioProcessor : public juce::AudioProcessor,
                                 public juce::AudioProcessorValueTreeState::Listener
{
public:
    BM800ToProAudioProcessor();
    ~BM800ToProAudioProcessor() override;

    void prepareToPlay(double sampleRate, int samplesPerBlock) override;
    void releaseResources() override;

    bool isBusesLayoutSupported(const BusesLayout& layouts) const override;
    void processBlock(juce::AudioBuffer<float>&, juce::MidiBuffer&) override;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }

    const juce::String getName() const override { return "BM800 to Pro - Vocal Enhancer"; }

    bool acceptsMidi() const override { return false; }
    bool producesMidi() const override { return false; }
    bool isMidiEffect() const override { return false; }
    double getTailLengthSeconds() const override { return 0.0; }

    int getNumPrograms() override { return 1; }
    int getCurrentProgram() override { return 0; }
    void setCurrentProgram(int) override {}
    const juce::String getProgramName(int) override { return {}; }
    void changeProgramName(int, const juce::String&) override {}

    void getStateInformation(juce::MemoryBlock& destData) override;
    void setStateInformation(const void* data, int sizeInBytes) override;

    void parameterChanged(const juce::String& parameterID, float newValue) override;

    juce::AudioProcessorValueTreeState& getAPVTS() { return apvts; }

    // Metering telemetry for GUI
    float getInputMeterLevel() const { return inputMeter.load(); }
    float getOutputMeterLevel() const { return outputMeter.load(); }
    float getGainReductionLevel() const { return gainReductionMeter.load(); }

    void applyPreset(int presetIndex);

private:
    juce::AudioProcessorValueTreeState::ParameterLayout createParameterLayout();
    void updateFilters();

    juce::AudioProcessorValueTreeState apvts;

    // 1. CLEAN: Noise Gate + 80Hz High Pass Filter
    juce::dsp::ProcessorDuplicator<juce::dsp::IIR::Filter<float>, juce::dsp::IIR::Coefficients<float>> highPassFilter;
    juce::dsp::NoiseGate<float> noiseGate;

    // 2. BODY: 150Hz Low Shelf EQ + Warm Saturation
    juce::dsp::ProcessorDuplicator<juce::dsp::IIR::Filter<float>, juce::dsp::IIR::Coefficients<float>> lowShelfFilter;
    juce::dsp::WaveShaper<float> warmSaturator;
    juce::dsp::ProcessorDuplicator<juce::dsp::IIR::Filter<float>, juce::dsp::IIR::Coefficients<float>> dcBlocker;

    // 3. PRO AIR: 10kHz High Shelf EQ + Exciter
    juce::dsp::ProcessorDuplicator<juce::dsp::IIR::Filter<float>, juce::dsp::IIR::Coefficients<float>> highShelfFilter;
    Exciter exciter;

    // 4. SMOOTH: De-Esser + Smooth Optical Compressor
    DeEsser deEsser;
    juce::dsp::Compressor<float> optoCompressor;

    // 5. LOUD: Fast FET Compressor + Peak Brickwall Limiter
    juce::dsp::Compressor<float> fastCompressor;
    juce::dsp::Limiter<float> brickwallLimiter;

    // Thread-safe level meters
    std::atomic<float> inputMeter { 0.0f };
    std::atomic<float> outputMeter { 0.0f };
    std::atomic<float> gainReductionMeter { 0.0f };

    double currentSampleRate = 44100.0;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(BM800ToProAudioProcessor)
};
