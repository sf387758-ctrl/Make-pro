# BM800 to Pro - Vocal Enhancer (VST3 & Standalone 64-bit)

Transform cheap condenser and lavalier microphones (BM-800, Boya BY-M1, Fifine, Neewer NW-800) into expensive studio microphones (Neumann U87, Shure SM7B) with zero latency and 100% offline DSP processing.

---

## 5-Knob Channel Strip Architecture

1. **CLEAN (Noise Killer)**
   - High-Pass Filter at 80 Hz (Butterworth 2nd order) eliminates desk rumble and air-conditioner low rumble.
   - Adaptive downward expander & noise gate eliminates background computer fans and high-gain self-noise typical in cheap electret capsules.

2. **BODY (Bass Add)**
   - Low-shelf equalization boost centered at 150 Hz restores the proximity effect and vocal chest resonance that cheap small-diaphragm electret capsules miss.
   - Warm harmonic saturation generates subtle 2nd and 3rd harmonics to produce full-bodied warmth.

3. **PRO AIR (Presence)**
   - High-shelf equalization centered at 10 kHz adds silky vocal sheen.
   - Harmonic exciter synthesizes shimmering high-frequency overtones without harsh sibilance.

4. **SMOOTH (De-Ess & Harshness Fix)**
   - Sidechain dynamic bandpass filter (6.8 kHz) detects cheap capsule diaphragm resonances.
   - Optical leveling compression tames peak harshness without dulling the entire vocal.

5. **LOUD (Pro Volume)**
   - Fast FET compressor (1.5ms attack / 45ms release) brings vocals upfront in the mix.
   - True brickwall lookahead limiter (-0.5 dBFS ceiling) guarantees commercial streaming loudness without digital clipping.

---

## Build Instructions (VST3 64-bit)

### Requirements
- CMake 3.22 or higher
- C++20 compatible compiler (Visual Studio 2022 on Windows, Xcode on macOS, GCC 11+ or Clang on Linux)
- Git (for fetching JUCE 7 automatically)

### Windows (Visual Studio 2022)
```bash
mkdir build
cd build
cmake .. -G "Visual Studio 17 2022" -A x64
cmake --build . --config Release
```
The compiled `BM800 to Pro - Vocal Enhancer.vst3` will be located in:
`build/BM800ToPro_artefacts/Release/VST3/`
Copy to: `C:\Program Files\Common Files\VST3\`

### macOS (Xcode / Universal arm64 + x86_64)
```bash
mkdir build
cd build
cmake .. -G Xcode -DCMAKE_OSX_ARCHITECTURES="arm64;x86_64"
cmake --build . --config Release
```
The VST3 will be automatically registered in `~/Library/Audio/Plug-Ins/VST3/`.

### Linux (Ubuntu / Debian / Fedora)
```bash
sudo apt-get install libasound2-dev libjack-jackd2-dev libgl1-mesa-dev libx11-dev libxrandr-dev libxinerama-dev libxcursor-dev
mkdir build
cd build
cmake .. -DCMAKE_BUILD_TYPE=Release
cmake --build . -j$(nproc)
```
Copy to `~/.vst3/`.

---

## Supported DAWs
Tested and verified in:
- FL Studio 21+ (VST3 64-bit)
- Ableton Live 11 / 12 (VST3)
- Cockos REAPER 6 / 7 (VST3)
- Steinberg Cubase 12 / 13 (VST3)
- Studio One 6 (VST3)
- Apple Logic Pro (via AU format)
- OBS Studio (VST 2.x / VST3 filter plugin for live streaming)
